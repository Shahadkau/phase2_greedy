//https://www.geeksforgeeks.org/printing-paths-dijkstras-shortest-path-algorithm/

package dijkstrasalgorithm;

import java.text.DecimalFormat;
import java.text.NumberFormat;

//the program use adjacency matrix representation of the graph.
class DijkstrasAlgorithm {

//the source vertix doesn't have parent vertix , it's the start one
    private static final int NO_PARENT = -1;

// methos that implements Dijkstra's single source shortest path
//the method takes the adjacency Matrix and the source vertex
    private static void dijkstra(int[][] adjacencyMatrix, int sourceVertex) {

        //hold the length number of "vertices/citis" will be equal 12
        int nVertices = adjacencyMatrix[0].length;

        // shortestDistances will hold the shortest distance from source "jeddah"  to i "any city"  
        int[] shortestDistances = new int[nVertices];

        // added[i] will be true if vertex i is included in shortest path tree 
        boolean[] added = new boolean[nVertices];

        // for loop to Initialize , i<less than nVertices wich is number of cities "12"
        for (int i = 0; i < nVertices; i++) {
            //Initialize all distances as INFINITE
            shortestDistances[i] = Integer.MAX_VALUE;
            // Initialize added[] as false no vertix yet in the shortest path tree
            added[i] = false;
        }

        // Distance of source vertex from itself is always 0
        shortestDistances[sourceVertex] = 0;

        // Parent array to store shortest path 
        int[] parents = new int[nVertices];

        // The source vertex "Jeddah" does not have a parent
        parents[sourceVertex] = NO_PARENT;

        // loop to Find the shortest path 
        for (int i = 1; i < nVertices; i++) {

            // Pick the minimum distance vertex from the set of vertices not yet in the shortest path tree .
            //initilize nearestVertex with -1
            int nearestVertex = -1;
            //initilize shortestDistance with Integer Max(Infinity)
            int shortestDistance = Integer.MAX_VALUE;
            for (int j = 0; j < nVertices; j++) {
                //if the vertix is false "not in the tree vertices" & shortestDistances[j] < shortestDistance
                if (added[j] == false && shortestDistances[j] < shortestDistance) {
                    // we found the nearest vertix
                    //store the index of the nearestVertex
                    nearestVertex = j;
                    shortestDistance = shortestDistances[j];
                }
            }

            // Mark the picked vertex as true "added to the tree vertices"
            added[nearestVertex] = true;

            // Update Distance value of the adjacent vertices of the picked vertex.
            for (int j = 0; j < nVertices; j++) {
                //the Distances of the cities from the nearestVertex
                int edgeDistance = adjacencyMatrix[nearestVertex][j];

                // check if the Distance from shortestDistance + edgeDistance less than edgeDistance or not 
                if (edgeDistance > 0 && ((shortestDistance + edgeDistance) < shortestDistances[j])) {
                    //store the nearest vertix to print the path
                    parents[j] = nearestVertex;
                    //store the shortest Distance
                    shortestDistances[j] = shortestDistance + edgeDistance;

                }
            }
        }

        // call printSolution to print the output 
        printSolution(sourceVertex, shortestDistances, parents);
    }

    // methos to print the distances
    // the method takes the source vertex "jeddah" , the distances from jeddah , the parents wich are the vertices path
    private static void printSolution(int sourceVertex, int[] distances, int[] parents) {

        //nVertices is the the number of vertices
        int nVertices = distances.length;
        System.out.print("      Cities\t\t       Distance     \t       Path");

        //for loop to print the output 
        // i represent the current vertix , 0 --> jeddah , 1 --> makkah ... etc
        for (int i = 0; i < nVertices; i++) {
            //if i is not 0 , 0 --> "jeddah" 
            if (i != sourceVertex) {
                switch (i) {

                    //index 1 means "Makkah"
                    case (1):
                        System.out.print("\n Jeddah -> Makkah \t\t ");
                        //print the shortest distance from jeddah to makkah
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 2 means "Madinah"
                    case (2):
                        System.out.print("\n Jeddah -> Madinah \t\t ");
                        //print the shortest distance from jeddah to Madinah
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 3 means "Riyadh"
                    case (3):
                        System.out.print("\n Jeddah -> Riyadh \t\t ");
                        //print the shortest distance from jeddah to Riyadh
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 4 means "Dammam"
                    case (4):
                        System.out.print("\n Jeddah -> Dammam \t\t ");
                        //print the shortest distance from jeddah to Dammam
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 5 means "Taif"
                    case (5):
                        System.out.print("\n Jeddah -> Taif \t\t ");
                        //print the shortest distance from jeddah to Taif
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 6 means "Abha"
                    case (6):
                        System.out.print("\n Jeddah -> Abha \t\t ");
                        //print the shortest distance from jeddah to Abha
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 7 means "Tabuk"
                    case (7):
                        System.out.print("\n Jeddah -> Tabuk \t\t ");
                        //print the shortest distance from jeddah to Tabuk
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 8 means "Qasim"
                    case (8):
                        System.out.print("\n Jeddah -> Qasim \t\t ");
                        //print the shortest distance from jeddah to Qasim
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 9 means "Hail"
                    case (9):
                        System.out.print("\n Jeddah -> Hail \t\t ");
                        //print the shortest distance from jeddah to Hail
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 10 means "Jizan"
                    case (10):
                        System.out.print("\n Jeddah -> Jizan \t\t ");
                        //print the shortest distance from jeddah to Jizan
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                    //index 11 means "Najran"
                    case (11):
                        System.out.print("\n Jeddah -> Najran \t\t ");
                        //print the shortest distance from jeddah to Najran
                        System.out.print(distances[i] + "\t\t");
                        //call method printPath to print the vertices path 
                        printPath(i, parents);
                        break;

                }
            }
        }
    }

    // Function to print shortest path from source using parents array
    private static void printPath(int currentVertex, int[] parents) {

        // to store the cities in the shortest path
        String store = "";

        //The source vertex does not have a parent "jeddah"
        if (currentVertex == NO_PARENT) {
            return;
        }
        //recursive call to the method to print all the virteces that represent the shortest path
        printPath(parents[currentVertex], parents);

        //replace the indeces with the cities name and save them in String "store" to print the path
        if (currentVertex == 0) {
            store += " Jeddah";

        } else if (currentVertex == 1) {
            store += "--> makkah";

        } else if (currentVertex == 2) {
            store += "--> Madinah";

        } else if (currentVertex == 3) {
            store += "--> Riyadh";

        } else if (currentVertex == 4) {
            store += "--> Dammam";

        } else if (currentVertex == 5) {
            store += "--> Taif";

        } else if (currentVertex == 6) {
            store += "--> Abha";

        } else if (currentVertex == 7) {
            store += "--> Tabuk";

        } else if (currentVertex == 8) {
            store += "--> Qasim";

        } else if (currentVertex == 9) {
            store += "--> Hail";

        } else if (currentVertex == 10) {
            store += "--> Jizan";

        } else if (currentVertex == 11) {
            store += "--> Najran";

        }
        //print the path
        System.out.print(store);

    }

    public static void main(String[] args) {
        // adjacency Matrix to represent the cities and the distences between them 
        int[][] adjacencyMatrix = {
            {0, 79, 420, 949, 1343, 167, 625, 1024, 863, 777, 710, 905},
            {79, 0, 358, 870, 1265, 88, 627, 1037, 876, 790, 685, 912},
            {420, 358, 0, 848, 1343, 446, 985, 679, 518, 432, 1043, 1270},
            {949, 870, 848, 0, 395, 782, 1064, 1304, 330, 640, 1272, 950},
            {1343, 1265, 1343, 395, 0, 1177, 1495, 1729, 725, 1035, 1667, 1345},
            {167, 88, 446, 782, 1177, 0, 561, 1204, 936, 957, 763, 864},
            {625, 627, 985, 1064, 1459, 561, 0, 1649, 1488, 1402, 202, 280},
            {1024, 1037, 679, 1304, 1729, 1204, 1649, 0, 974, 664, 1722, 1929},
            {863, 876, 518, 330, 725, 936, 1488, 974, 0, 310, 1561, 1280},
            {777, 790, 432, 640, 1035, 957, 1402, 664, 974, 0, 1475, 1590},
            {710, 685, 1043, 1272, 1667, 763, 202, 1722, 1561, 1475, 0, 482},
            {905, 912, 1270, 950, 1345, 864, 280, 1929, 1280, 1590, 482, 0}};

        //call the method  dijkstra with the adjacency Matrix and the source vertex index 0 wich is Jeddah
       
        long start_Time1 = System.currentTimeMillis();
        dijkstra(adjacencyMatrix, 0);
        long end_Time1 = System.currentTimeMillis();
        long totalTime = end_Time1 - start_Time1;
        NumberFormat formatter = new DecimalFormat("#0.00000");
       System.out.println("\nrunning times of (Dijkstra) : "+formatter.format((totalTime) / 1000d) + " seconds");
    }
}
